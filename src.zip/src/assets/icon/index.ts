import Person from './svg/person.svg';

export { Person };
