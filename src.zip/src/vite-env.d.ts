/// <reference types="vite/client" />

// Uncomment in case of problems with ImportMeta.env types
// interface ImportMeta {
//   env: Record<string, string>;
// }
