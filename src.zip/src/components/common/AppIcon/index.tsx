import AppIcon from './AppIcon';

export default AppIcon;
