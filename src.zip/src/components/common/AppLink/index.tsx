import AppLink from './AppLink';

export default AppLink;
