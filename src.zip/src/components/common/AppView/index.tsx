import AppView from './AppView';

export default AppView;
