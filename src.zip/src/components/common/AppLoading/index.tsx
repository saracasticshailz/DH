import AppLoading from './AppLoading';

export default AppLoading;
