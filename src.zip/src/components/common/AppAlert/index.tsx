import AppAlert from './AppAlert';

export default AppAlert;
