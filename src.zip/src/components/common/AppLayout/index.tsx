import AuthFooter from './AuthFooter';
import AuthHeader from './AuthHeader';
export { AuthFooter, AuthHeader };
