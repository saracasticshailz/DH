import UserInfo from './UserInfo';

export default UserInfo;
