import AuthView from './AuthView';

export default AuthView;
