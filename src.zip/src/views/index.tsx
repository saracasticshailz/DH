import NotImplementedView from './NotImplementedView';
import NotFoundView from './NotFoundView';

export { NotFoundView, NotImplementedView as UserView };
