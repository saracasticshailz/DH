import WelcomeView from './WelcomeView';

export default WelcomeView;
