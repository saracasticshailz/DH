declare global {
  interface Window {
    kony: any;
    lruCache: any;
  }
}
export {};
