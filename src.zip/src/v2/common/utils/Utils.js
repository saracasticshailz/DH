export function print(msg) {
  console.log(msg);
}
