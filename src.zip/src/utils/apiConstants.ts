export const MOD_CONSTANTS = {
  REGISTER: 'register',
};
